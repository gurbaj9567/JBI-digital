import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lets-talk',
  templateUrl: './lets-talk.component.html',
  styleUrls: ['./lets-talk.component.sass']
})
export class LetsTalkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
