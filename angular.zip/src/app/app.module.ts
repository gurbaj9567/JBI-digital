import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewCmpComponent } from './new-cmp/new-cmp.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { OurClientsComponent } from './our-clients/our-clients.component';
import { BannerComponent } from './banner/banner.component';
import { DiscoverComponent } from './discover/discover.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { PartnersComponent } from './partners/partners.component';
import { ClientsSayComponent } from './clients-say/clients-say.component';
import { LetsTalkComponent } from './lets-talk/lets-talk.component';

@NgModule({
  declarations: [
    AppComponent,
    NewCmpComponent,
    HeaderComponent,
    FooterComponent,
    OurClientsComponent,
    BannerComponent,
    DiscoverComponent,
    ContactUsComponent,
    PartnersComponent,
    ClientsSayComponent,
    LetsTalkComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
