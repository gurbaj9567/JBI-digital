import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-clients',
  templateUrl: './our-clients.component.html',
  styleUrls: ['./our-clients.component.sass']
})
export class OurClientsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
