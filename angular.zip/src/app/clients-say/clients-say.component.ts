import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clients-say',
  templateUrl: './clients-say.component.html',
  styleUrls: ['./clients-say.component.sass']
})
export class ClientsSayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
